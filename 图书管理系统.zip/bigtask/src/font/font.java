package font;

import java.awt.*;

public class font {
    public static Font textfont1 = new Font("等线",Font.PLAIN,17);
    public static Font textfont2 = new Font("等线",Font.PLAIN,12);
    public static Font titlefont1 = new Font("等线",Font.BOLD,50);
    public static Font titlefont2 = new Font("等线",Font.PLAIN,20);
}