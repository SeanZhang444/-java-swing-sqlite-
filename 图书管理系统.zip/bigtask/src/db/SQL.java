package db;

import java.sql.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import object.*;

public class SQL {
    Connection c = null;
    Statement statement = null;
    String sql;
    public SQL(){
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:bigtask/db/id.sqlite3");
            statement = c.createStatement();
        }catch(Exception e){
            System.err.println("错误：无法连接数据库！");
            System.exit(0);
        }
    }

    public ResultSet findStudent(Student student) {
        try {
            return statement.executeQuery("select * from student where id='"
                    +student.getId()+"' and password='"+student.getPassword()+"'");
        }catch(Exception e) {
            return null;
        }
    }
    public int insertStudent(Student student) {
        try {
            return statement.executeUpdate("insert into student values('"
                    + student.getId() + "','" + student.getName() + "','" + student.getPassword() + "')");
        } catch (Exception e) {
            return 0;
        }
    }
    public int updateStudentName(String id,String name){
        try{
            return statement.executeUpdate("update student set name='" +name
                    +"' where id='"+id+"'");
        }catch(Exception e){
            return 0;
        }
    }
    public int updateStudentPassword(String id,String password){
        try{
            return statement.executeUpdate("update student set password='"+password
                    +"' where id='"+id+"'");
        }catch(Exception e){
            return 0;
        }
    }
    public ResultSet showStudent(String id){
        try{
            return statement.executeQuery("select id,name from student where id='"+id+"'");
        }catch(Exception e){
            return null;
        }
    }
    public ResultSet findManager(Manager manager) {
        try {
            return statement.executeQuery("select * from manager where id='"
                    +manager.getId()+"' and password='"+manager.getPassword()+"'");
        }catch(Exception e) {
            return null;
        }
    }
    public ResultSet showManager(String id){
        try{
            return statement.executeQuery("select id,name from manager where id='"+id+"'");
        }catch(Exception e){
            return null;
        }
    }
    public int updateManagerName(String id,String name){
        try{
            return statement.executeUpdate("update manager set name='"
                    + name +"' where id='"+id+"'");
        }catch(Exception e){
            return 0;
        }
    }
    public int updateManagerPassword(String id,String password){
        try{
            return statement.executeUpdate("update manager set password='"
                    + password +"' where id='"+id+"'");
        }catch(Exception e){
            return 0;
        }
    }
    public ResultSet listBook(Book book){
        try{
            sql = "select * from book where 1";
            if(!book.getName().equals("")){
                sql = sql + " and name like '%" + book.getName() +"%'";
            }
            if(!book.getAuthor().equals("")){
                sql = sql + " and author like '%" + book.getAuthor() +"%'";
            }
            if(!book.getISBN().equals("")){
                sql = sql + " and ISBN like '%" + book.getISBN() +"%'";
            }
            if(!book.getPublish().equals("")){
                sql = sql + " and publish like '%" + book.getPublish() +"%'";
            }
            if(book.getNumber()!=0){
                sql = sql + " and number>0";
            }
            return statement.executeQuery(sql);
        }catch(Exception e){
            return null;
        }
    }
    public int insertBook(Book book){
        try {
            return statement.executeUpdate("insert into book values('"
                    + book.getName() + "','" + book.getAuthor() + "','"
                    + book.getISBN() + "','" + book.getPublish() + "',"
                    + book.getNumber() + ")");
        } catch(Exception e) {
            System.err.println(e.getMessage());
            return 0;
        }
    }
    public int updateBook(Book book){
        try{
            return statement.executeUpdate("update book set name='"+book.getName()+"',author='"
            +book.getAuthor()+"',publish='"+book.getPublish()+"',number="
            +book.getNumber()+" where ISBN='"+book.getISBN()+"'");
        }catch(Exception e){
            return 0;
        }
    }
    public int borrowBook(Book book){
        try {
            return statement.executeUpdate("update book set number=number-1 where ISBN='" + book.getISBN()
                    + "' and number>0");
        }catch(Exception e){
            return 0;
        }
    }
    public int returnBook(Book book){
        try {
            return statement.executeUpdate("update book set number=number+1 where ISBN='"+book.getISBN()
                    +"'");
        } catch(Exception e) {
            return 0;
        }
    }
    public int deleteBook(String ISBN){
        try{
            return statement.executeUpdate("delete from book where ISBN='"+ISBN+"'");
        }catch(Exception e){
            return 0;
        }
    }
    public ResultSet showBook(String ISBN){
        try{
            return statement.executeQuery("select * from book where ISBN='"+ISBN+"'");
        }catch(Exception e){
            return null;
        }
    }
    public ResultSet SB(Student student,Book book,String day){
        try{
            sql = "select * from SB where id in (select id from student where 1";
            if(!student.getId().equals("")){
                sql = sql + " and id like '%" + student.getId() + "%'";
            }
            if(!student.getName().equals("")){
                sql = sql + " and name like '%" + student.getName() + "%'";
            }
            sql = sql + ") and ISBN in (select ISBN from book where 1";
            if(!book.getName().equals("")){
                sql = sql + " and name like '%" + book.getName() + "%'";
            }
            if(!book.getAuthor().equals("")){
                sql = sql + " and author like '%" + book.getAuthor() + "%'";
            }
            if(!book.getISBN().equals("")){
                sql = sql + " and ISBN like '%" + book.getISBN() + "%'";
            }
            if(!book.getPublish().equals("")){
                sql = sql + " and publish like '%" + book.getPublish() + "%'";
            }
            sql = sql + ")";
            if(!day.equals("")) {
                sql = sql + "and day like '%" + day + "%'";
            }
            return statement.executeQuery(sql);
        }catch(Exception e){
            return null;
        }
    }
    public int insertSB(Student student,Book book){
        try {
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            return statement.executeUpdate("insert into SB values('" + student.getId() +
                    "','" + book.getISBN() + "','" + dateFormat.format(date) + "')");
        } catch(Exception e) {
            return 0;
        }
    }
    public int deleteSB(String id,String ISBN,String day){
        try {
            sql = "delete from SB where id='"+id+ "' and ISBN='"+ISBN+"'";
            if(!day.equals("")){
                sql = sql + "and day='"+day+"'";
            }
            return statement.executeUpdate(sql);
        } catch(Exception e) {
            return 0;
        }
    }
    public int findSB(String ISBN){
        try {
            ResultSet rs = statement.executeQuery("select * from SB where ISBN='"+ISBN+"'");
            if(rs.next()){
                return 1;
            }else{
                return 0;
            }
        }catch(Exception e) {
            return -1;
        }
    }
}
