package object;

public class Book {
    private String name = "";
    private String author = "";
    private String ISBN = "";
    private String publish = "";
    private int number = 0;
    public Book(String name,String author,String ISBN,String publish,int number){
        this.name = name;
        this.author = author;
        this.ISBN = ISBN;
        this.publish = publish;
        this.number = number;
    }
    public String getName(){
        return name;
    }
    public String getAuthor(){
        return author;
    }
    public String getISBN(){
        return ISBN;
    }
    public String getPublish(){
        return publish;
    }
    public int getNumber(){
        return number;
    }
}
