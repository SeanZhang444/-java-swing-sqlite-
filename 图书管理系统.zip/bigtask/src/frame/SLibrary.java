package frame;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.List;

import static font.font.*;
import db.*;
import object.*;

public class SLibrary extends JFrame {
    private class SearchTextField extends JTextField{
        public SearchTextField(){
            setFont(textfont2);
            getDocument().addDocumentListener(new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {
                    Search();
                }
                @Override
                public void removeUpdate(DocumentEvent e) {
                    Search();
                }
                @Override
                public void changedUpdate(DocumentEvent e) {}
            });
        }
    }
    private JPanel root;
    private JLabel background,searchLabel, studentLabel;
    private JTextField nameTextField,authorTextField,ISBNTextField,publishTextField;
    private JRadioButton numberButton;
    private JButton informationButton, exitButton,studentButton;
    private DefaultTableModel bookTableModel;
    private JTable bookTable;
    private Object[][] data;
    private String[] columnNames = {"书名","作者","ISBN","出版社","数量"};

    public SLibrary(Student student) {

        setTitle("图书管理系统-学生端");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);         //设置面板为绝对布局

        //学生信息
        studentLabel = new JLabel("学号："+student.getId()+"  名字："+student.getName());
        studentLabel.setBounds(220, 10, 500, 50);
        studentLabel.setFont(titlefont2);
        studentLabel.setForeground(Color.white);
        root.add(studentLabel);

        //书籍表格
        bookTableModel = new DefaultTableModel(data,columnNames);
        bookTable = new JTable(bookTableModel){
            public boolean isCellEditable(int row,int column){
                return false;
            }
        };
        bookTable .getTableHeader().setReorderingAllowed(false);
        bookTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if(e.getClickCount() == 2){
                    int row = bookTable.getSelectedRow();
                    Book book = new Book(bookTable.getValueAt(row,0).toString(),bookTable.getValueAt(row,1).toString(),
                            bookTable.getValueAt(row,2).toString(),bookTable.getValueAt(row,3).toString(),
                            Integer.parseInt(bookTable.getValueAt(row,4).toString()));
                    new SBorrowBook(student,book).addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            super.windowClosed(e);
                            Search();
                        }
                    });
                }
            }
        });
        bookTable.setAutoCreateRowSorter(true);
        JScrollPane scroll = new JScrollPane(bookTable);
        scroll.setBounds(100,70,600,300);
        root.add(scroll);

        //搜索标签
        searchLabel = new JLabel("搜索框");
        searchLabel.setBounds(40, 390, 100, 20);
        searchLabel.setFont(textfont1);
        searchLabel.setForeground(Color.white);
        root.add(searchLabel);

        //搜索文本框
        nameTextField = new SearchTextField();
        nameTextField.setBounds(100, 390, 120, 20);
        root.add(nameTextField);
        authorTextField = new SearchTextField();
        authorTextField.setBounds(220, 390, 120, 20);
        root.add(authorTextField);
        ISBNTextField = new SearchTextField();
        ISBNTextField.setBounds(340, 390, 120, 20);
        root.add(ISBNTextField);
        publishTextField = new SearchTextField();
        publishTextField.setBounds(460, 390, 120, 20);
        root.add(publishTextField);

        //数量按钮（只显示数量不为0的书籍）
        numberButton = new JRadioButton("只看数量大于0的书籍",false);
        numberButton.setFont(textfont2);
        numberButton.setBounds(580,390,200,20);
        numberButton.setContentAreaFilled(false);
        numberButton.setForeground(Color.white);
        numberButton.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                Search();
            }
        });
        root.add(numberButton);

        //初始化搜索
        Search();

        //查看借书按钮
        studentButton = new JButton("我的借书");          //定义按钮对象
        studentButton.setBounds(200, 450, 120, 40);
        studentButton.setFont(textfont1);
        studentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SBook(student).addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosed(WindowEvent e) {
                        super.windowClosed(e);
                        Search();
                    }
                });
            }
        });
        root.add(studentButton);

        //修改信息按钮
        informationButton = new JButton("修改信息");          //定义按钮对象
        informationButton.setBounds(340, 450, 120, 40);
        informationButton.setFont(textfont1);
        informationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SInformation(student).addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosed(WindowEvent e) {
                        super.windowClosed(e);
                        ResultSet rs = new SQL().showStudent(student.getId());
                        try {
                            student.setName(rs.getString("name"));
                        }catch(Exception e1){}
                        studentLabel.setText("学号："+student.getId()+"  名字："+student.getName());
                        root.updateUI();
                    }
                });
            }
        });
        root.add(informationButton);

        //退出按钮
        exitButton = new JButton("退出");          //定义按钮对象
        exitButton.setBounds(480, 450, 120, 40);
        exitButton.setFont(textfont1);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Login();
                dispose();
            }
        });
        root.add(exitButton);

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,800,600);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    //搜索函数
    private void Search(){
        int flag = 0;
        if(numberButton.isSelected()){
            flag = 1;
        }
        Book book = new Book(nameTextField.getText(),authorTextField.getText(),
                ISBNTextField.getText(),publishTextField.getText(),flag);
        ResultSet rs = new SQL().listBook(book);
        try{
            List sortkey = bookTable.getRowSorter().getSortKeys();
            bookTable.getRowSorter().setSortKeys(null);
            bookTableModel.getDataVector().clear();
            bookTableModel.fireTableDataChanged();
            Object[] rowdata;
            while(rs.next()){
                rowdata = new Object[5];
                rowdata[0] = rs.getString("name");
                rowdata[1] = rs.getString("author");
                rowdata[2] = rs.getString("ISBN");
                rowdata[3] = rs.getString("publish");
                rowdata[4] = rs.getInt("number");
                bookTableModel.addRow(rowdata);
            }
            bookTable.getRowSorter().setSortKeys(sortkey);
            bookTable.updateUI();
        }catch(Exception e1){}
    }
}
