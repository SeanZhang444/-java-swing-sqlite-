package frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;

import static font.font.*;
import db.*;
import object.*;

class LoginDialog extends JDialog{
    JButton confirmButton;
    public LoginDialog(Login frame) {
        super(frame, "登录", true);
        setLayout(null);
        //文本框
        JLabel jl;
        jl = new JLabel("id或密码错误！");
        jl.setBounds(90, 40, 200, 20);
        jl.setFont(textfont1);
        add(jl);

        //确认按钮
        confirmButton = new JButton("确认");
        confirmButton.setBounds(100, 100, 80, 40);
        confirmButton.setFont(textfont1);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(confirmButton);

        setSize(300,200);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
public class Login extends JFrame {

    private JPanel root;
    private JLabel background,titleLabel,idLabel,passWordLabel;
    private JTextField idTextField;
    private JRadioButton managerButton,studentButton;
    private JButton enterButton,registerButton;
    private JPasswordField passWordTextField;
    public Login() {

        setTitle("图书管理系统-登录界面");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);         //设置面板为绝对布局

        //标题标签
        titleLabel = new JLabel("图书管理系统");
        titleLabel.setBounds(250, 120, 300, 50);
        titleLabel.setFont(titlefont1);
        titleLabel.setForeground(Color.white);
        root.add(titleLabel);

        //学号标签
        idLabel = new JLabel("学号/id");
        idLabel.setBounds(210, 255, 100, 20);
        idLabel.setFont(titlefont2);
        idLabel.setForeground(Color.white);
        root.add(idLabel);

        //用户名文本框
        idTextField = new JTextField();
        idTextField.setBounds(290, 250, 240, 30);
        idTextField.setFont(textfont1);
        idTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(e.getKeyChar()<'0' || e.getKeyChar()>'9' || e.getKeyCode()==8 || idTextField.getText().length()>=12){
                    e.consume();
                }
            }
        });
        root.add(idTextField);

        //密码标签
        passWordLabel = new JLabel("密 码");       //定义标签对象
        passWordLabel.setBounds(220, 305, 100, 20);
        passWordLabel.setFont(titlefont2);
        passWordLabel.setForeground(Color.white);
        root.add(passWordLabel);

        //密码文本框
        passWordTextField = new JPasswordField(12);
        passWordTextField.setBounds(290, 300, 240, 30);
        passWordTextField.setFont(textfont1);
        passWordTextField.setEchoChar('●');       //设置回显字符
        root.add(passWordTextField);

        ButtonGroup group = new ButtonGroup();
        //学生单选按钮
        studentButton = new JRadioButton("学生",true);
        studentButton.setFont(textfont1);
        studentButton.setBounds(280,350,80,40);
        studentButton.setContentAreaFilled(false);
        studentButton.setForeground(Color.white);
        root.add(studentButton);
        group.add(studentButton);

        //管理员单选按钮
        managerButton = new JRadioButton("管理员",false);
        managerButton.setFont(textfont1);
        managerButton.setBounds(400,350,80,40);
        managerButton.setContentAreaFilled(false);
        managerButton.setForeground(Color.white);
        root.add(managerButton);
        group.add(managerButton);


        //登录按钮
        enterButton = new JButton("登录");          //定义按钮对象
        enterButton.setBounds(280, 400, 80, 40);
        enterButton.setFont(textfont1);
        enterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(studentButton.isSelected()){
                    Student student = new Student(idTextField.getText(),"",passWordTextField.getText());
                    ResultSet rs = new SQL().findStudent(student);
                    try {
                        if (rs.next()) {
                            new SLibrary(new Student(rs.getString("id"),rs.getString("name"),""));
                            dispose();
                        } else {
                            new LoginDialog(Login.this);
                        }
                    }catch (SQLException e1){}
                }
                else if(managerButton.isSelected()){
                    Manager manager = new Manager(idTextField.getText(),"",passWordTextField.getText());
                    ResultSet rs = new SQL().findManager(manager);
                    try {
                        if (rs.next()) {
                            new MLibrary(new Manager(rs.getString("id"),rs.getString("name"),""));
                            dispose();
                        } else {
                            new LoginDialog(Login.this);
                        }
                    }catch (SQLException e1){}
                }
            }
        });
        root.add(enterButton);

        //注册按钮
        registerButton = new JButton("注册");
        registerButton.setBounds(400, 400, 80, 40);
        registerButton.setFont(textfont1);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Register();
            }
        });
        root.add(registerButton);

        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,800,600);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
