import frame.Login;

import javax.swing.*;

public class Main{
    //main方法
    public static void main(String[] args) {
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            SwingUtilities.updateComponentTreeUI(new Login());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}