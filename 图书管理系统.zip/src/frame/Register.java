package frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static font.font.*;
import db.*;
import object.*;

class RegisterDialog extends JDialog{
    JButton confirmButton;
    public RegisterDialog(Register frame,int i) {
        super(frame, "注册", true);
        setLayout(null);
        //文本框
        JLabel jl;
        if(i==1){
            jl = new JLabel("注册成功！");
        }
        else{
            jl = new JLabel("学号已存在！");
        }
        jl.setBounds(100, 40, 200, 20);
        jl.setFont(textfont1);
        add(jl);

        //确认按钮
        confirmButton = new JButton("确认");
        confirmButton.setBounds(100, 100, 80, 40);
        confirmButton.setFont(textfont1);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(confirmButton);

        setSize(300,200);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

public class Register extends JFrame{
    private JPanel root;
    private JLabel background,idLabel,userNameLabel,passWordLabel,confirmPassWordLabel;
    private JLabel idWrongLabel,userWrongLabel,passwordWrongLabel,confirmPasswordWrongLabel;
    private JTextField idTextField,userTextField;
    private JButton registerButton,cancelButton;
    private JPasswordField passWordTextField,confirmPassWordTextField;
    public Register(){

        setTitle("图书管理系统-注册界面");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);

        //学号标签
        idLabel = new JLabel("学 号");
        idLabel.setBounds(220, 105, 100, 20);
        idLabel.setFont(titlefont2);
        idLabel.setForeground(Color.white);
        root.add(idLabel);

        //学号错误文本框
        idWrongLabel = new JLabel("请输入12位学号！");
        idWrongLabel.setBounds(540,105,200,20);
        idWrongLabel.setFont(textfont1);
        idWrongLabel.setForeground(Color.RED);
        idWrongLabel.setVisible(false);
        root.add(idWrongLabel);

        //学号文本框
        idTextField = new JTextField(12);
        idTextField.setBounds(290, 100, 240, 30);
        idTextField.setFont(textfont1);
        idTextField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {}
            @Override
            public void focusLost(FocusEvent e) {
                if(idTextField.getText().length()<12){
                    idWrongLabel.setVisible(true);
                }
                else{
                    idWrongLabel.setVisible(false);
                }
            }
        });
        idTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(e.getKeyChar()<'0' || e.getKeyChar()>'9' || e.getKeyCode()==8 || idTextField.getText().length()>=12){
                    e.consume();
                }
            }
        });
        root.add(idTextField);

        //用户名标签
        userNameLabel = new JLabel("用户名");
        userNameLabel.setBounds(210, 155, 100, 20);
        userNameLabel.setFont(titlefont2);
        userNameLabel.setForeground(Color.white);
        root.add(userNameLabel);

        //用户名错误文本框
        userWrongLabel = new JLabel("用户名不能为空！");
        userWrongLabel.setBounds(540,155,200,20);
        userWrongLabel.setFont(textfont1);
        userWrongLabel.setForeground(Color.RED);
        userWrongLabel.setVisible(false);
        root.add(userWrongLabel);

        //用户名文本框
        userTextField = new JTextField(12);
        userTextField.setBounds(290, 150, 240, 30);
        userTextField.setFont(textfont1);
        root.add(userTextField);
        userTextField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {}
            @Override
            public void focusLost(FocusEvent e) {
                if(userTextField.getText().length()==0){
                    userWrongLabel.setVisible(true);
                }
                else{
                    userWrongLabel.setVisible(false);
                }
            }
        });
        userTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(e.getKeyCode()==8 || userTextField.getText().length()>=20){
                    e.consume();
                }
            }
        });

        //密码标签
        passWordLabel = new JLabel("密 码");       //定义标签对象
        passWordLabel.setBounds(220, 205, 100, 20);
        passWordLabel.setFont(titlefont2);
        passWordLabel.setForeground(Color.white);
        root.add(passWordLabel);

        //密码错误文本框
        passwordWrongLabel = new JLabel("密码为6~20位！");
        passwordWrongLabel.setBounds(540,205,200,20);
        passwordWrongLabel.setFont(textfont1);
        passwordWrongLabel.setForeground(Color.RED);
        passwordWrongLabel.setVisible(false);
        root.add(passwordWrongLabel);

        //密码文本框
        passWordTextField = new JPasswordField(12);
        passWordTextField.setBounds(290, 200, 240, 30);
        passWordTextField.setFont(textfont1);
        passWordTextField.setEchoChar('●');       //设置回显字符
        passWordTextField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {}
            @Override
            public void focusLost(FocusEvent e) {
                if(passWordTextField.getText().length()<6){
                    passwordWrongLabel.setVisible(true);
                }
                else{
                    passwordWrongLabel.setVisible(false);
                }
            }
        });
        passWordTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(e.getKeyCode()==8 || passWordTextField.getText().length()>=20){
                    e.consume();
                }
            }
        });
        root.add(passWordTextField);

        //确认密码标签
        confirmPassWordLabel = new JLabel("确认密码");       //定义标签对象
        confirmPassWordLabel.setBounds(200, 255, 100, 20);
        confirmPassWordLabel.setFont(titlefont2);
        confirmPassWordLabel.setForeground(Color.white);
        root.add(confirmPassWordLabel);

        //确认密码错误文本框
        confirmPasswordWrongLabel = new JLabel("确认密码与原密码不一致！");
        confirmPasswordWrongLabel.setBounds(540,255,200,20);
        confirmPasswordWrongLabel.setFont(textfont1);
        confirmPasswordWrongLabel.setForeground(Color.RED);
        confirmPasswordWrongLabel.setVisible(false);
        root.add(confirmPasswordWrongLabel);

        //确认密码文本框
        confirmPassWordTextField = new JPasswordField(12);
        confirmPassWordTextField.setBounds(290, 250, 240, 30);
        confirmPassWordTextField.setFont(textfont1);
        confirmPassWordTextField.setEchoChar('●');       //设置回显字符
        confirmPassWordTextField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {}
            @Override
            public void focusLost(FocusEvent e) {
                if(!confirmPassWordTextField.getText().equals(passWordTextField.getText())){
                    confirmPasswordWrongLabel.setVisible(true);
                }
                else{
                    confirmPasswordWrongLabel.setVisible(false);
                }
            }
        });
        confirmPassWordTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(e.getKeyCode()==8 || confirmPassWordTextField.getText().length()>=20){
                    e.consume();
                }
            }
        });
        root.add(confirmPassWordTextField);

        //注册按钮
        registerButton = new JButton("注册");
        registerButton.setBounds(300, 350, 80, 40);
        registerButton.setFont(textfont1);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //判断必填信息是否为空或不符合要求
                if(idTextField.getText().length()==12 && !userTextField.getText().equals("")
                        && !passWordTextField.getText().equals("") && passWordTextField.getText().length()>=6
                        && passWordTextField.getText().length()<=20 && confirmPassWordTextField.getText().equals(passWordTextField.getText()))
                {
                    //尝试加入数据库
                    Student student = new Student(idTextField.getText(),userTextField.getText(),passWordTextField.getText());
                    //注册成功退出界面，失败返回
                    if (new SQL().insertStudent(student) != 0) {
                        new RegisterDialog(Register.this, 1);
                        dispose();
                    } else {
                        new RegisterDialog(Register.this, 0);
                    }
                }
            }
        });
        root.add(registerButton);

        //取消按钮
        cancelButton = new JButton("取消");
        cancelButton.setBounds(400, 350, 80, 40);
        cancelButton.setFont(textfont1);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        root.add(cancelButton);

        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,800,600);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
