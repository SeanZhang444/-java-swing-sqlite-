package frame;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.List;

import static font.font.*;
import db.*;
import object.*;

public class MStudent extends JFrame {
    private class SearchTextField extends JTextField{
        public SearchTextField(){
            setFont(textfont2);
            getDocument().addDocumentListener(new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {
                    Search();
                }
                @Override
                public void removeUpdate(DocumentEvent e) {
                    Search();
                }
                @Override
                public void changedUpdate(DocumentEvent e) {}
            });
        }
    }
    private JPanel root;
    private JLabel background,searchLabel;
    private JTextField idTextField, nameTextField, booknameTextField,authorTextField,
            publishTextField, ISBNTextField,dayTextField;
    private DefaultTableModel borrowTableModel;
    private JTable borrowTable;
    private Object[][] data;
    private String[] columnNames = {"学号","姓名","书名","作者","出版社","ISBN","日期"};

    public MStudent() {

        setTitle("学生借书情况");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);         //设置面板为绝对布局

        //借书表格
        borrowTableModel = new DefaultTableModel(data,columnNames);
        borrowTable = new JTable(borrowTableModel){
            public boolean isCellEditable(int row,int column){
                return false;
            }
        };
        borrowTable .getTableHeader().setReorderingAllowed(false);
        borrowTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if(e.getClickCount() == 2) {
                    int row = borrowTable.getSelectedRow();
                    Student student = new Student(borrowTable.getValueAt(row, 0).toString(), borrowTable.getValueAt(row, 1).toString(), "");
                    Book book = new Book(borrowTable.getValueAt(row, 2).toString(), borrowTable.getValueAt(row, 3).toString(),
                            borrowTable.getValueAt(row, 5).toString(), borrowTable.getValueAt(row, 4).toString(), 0);
                    String day = borrowTable.getValueAt(row, 6).toString();
                    new MReturnBook(student,book,day).addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            super.windowClosed(e);
                            Search();
                        }
                    });
                }
            }
        });
        borrowTable.setAutoCreateRowSorter(true);
        JScrollPane scroll = new JScrollPane(borrowTable);
        scroll.setBounds(50,50,700,300);
        root.add(scroll);

        //搜索标签
        searchLabel = new JLabel("搜索框");
        searchLabel.setBounds(50, 370, 100, 20);
        searchLabel.setFont(textfont1);
        searchLabel.setForeground(Color.white);
        root.add(searchLabel);

        //搜索文本框
        idTextField = new SearchTextField();
        idTextField.setBounds(50, 400, 100, 20);
        root.add(idTextField);
        nameTextField = new SearchTextField();
        nameTextField.setBounds(150, 400, 100, 20);
        root.add(nameTextField);
        booknameTextField = new SearchTextField();
        booknameTextField.setBounds(250, 400, 100, 20);
        root.add(booknameTextField);
        authorTextField = new SearchTextField();
        authorTextField.setBounds(350, 400, 100, 20);
        root.add(authorTextField);
        publishTextField = new SearchTextField();
        publishTextField.setBounds(450, 400, 100, 20);
        root.add(publishTextField);
        ISBNTextField = new SearchTextField();
        ISBNTextField.setBounds(550, 400, 100, 20);
        root.add(ISBNTextField);
        dayTextField = new SearchTextField();
        dayTextField.setBounds(650, 400, 100, 20);
        root.add(dayTextField);

        //初始化搜索
        Search();

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,800,600);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void Search(){
        Student student = new Student(idTextField.getText(),nameTextField.getText(),"");
        Book book = new Book(booknameTextField.getText(),authorTextField.getText(),
                ISBNTextField.getText(),publishTextField.getText(),0);
        String day = dayTextField.getText();
        ResultSet rs = new SQL().SB(student,book,day);
        try{
            List sortkey = borrowTable.getRowSorter().getSortKeys();
            borrowTable.getRowSorter().setSortKeys(null);
            borrowTableModel.getDataVector().clear();
            borrowTableModel.fireTableDataChanged();
            Object[] rowdata;
            while(rs.next()){
                ResultSet rs1 = new SQL().showStudent(rs.getString("id"));
                ResultSet rs2 = new SQL().showBook(rs.getString("ISBN"));
                rowdata = new Object[7];
                rowdata[0] = rs1.getString("id");
                rowdata[1] = rs1.getString("name");
                rowdata[2] = rs2.getString("name");
                rowdata[3] = rs2.getString("author");
                rowdata[4] = rs2.getString("publish");
                rowdata[5] = rs2.getString("ISBN");
                rowdata[6] = rs.getString("day");
                borrowTableModel.addRow(rowdata);
            }
            borrowTable.getRowSorter().setSortKeys(sortkey);
            borrowTable.updateUI();
        }catch(Exception e1){
            System.err.println(e1.getMessage());
        }
    }
}

