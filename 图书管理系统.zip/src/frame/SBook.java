package frame;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.List;

import static font.font.*;
import db.*;
import object.*;

public class SBook extends JFrame {
    private class SearchTextField extends JTextField{
        public SearchTextField(Student student){
            setFont(textfont2);
            getDocument().addDocumentListener(new DocumentListener() {
                @Override
                public void insertUpdate(DocumentEvent e) {
                    Search(student);
                }
                @Override
                public void removeUpdate(DocumentEvent e) {
                    Search(student);
                }
                @Override
                public void changedUpdate(DocumentEvent e) {}
            });
        }
    }
    private JPanel root;
    private JLabel background,searchLabel;
    private JTextField booknameTextField,authorTextField, publishTextField, ISBNTextField,dayTextField;
    private DefaultTableModel MyborrowTableModel;
    private JTable MyborrowTable;
    private Object[][] data;
    private String[] columnNames = {"书名","作者","ISBN","出版社","日期"};

    public SBook(Student student) {

        setTitle("我的借书情况");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);         //设置面板为绝对布局

        //借书表格
        MyborrowTableModel = new DefaultTableModel(data,columnNames);
        MyborrowTable = new JTable(MyborrowTableModel){
            public boolean isCellEditable(int row,int column){
                return false;
            }
        };
        MyborrowTable.getTableHeader().setReorderingAllowed(false);
        MyborrowTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if(e.getClickCount() == 2){
                    int row = MyborrowTable.getSelectedRow();
                    Book book = new Book(MyborrowTable.getValueAt(row,0).toString(),MyborrowTable.getValueAt(row,1).toString(),
                            MyborrowTable.getValueAt(row,2).toString(),MyborrowTable.getValueAt(row,3).toString(),0);
                    new SReturnBook(student,book,MyborrowTable.getValueAt(row,4).toString()).addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            super.windowClosed(e);
                            Search(student);
                        }
                    });
                }
            }
        });
        MyborrowTable.setAutoCreateRowSorter(true);
        JScrollPane scroll = new JScrollPane(MyborrowTable);
        scroll.setBounds(50,50,700,300);
        root.add(scroll);

        //搜索标签
        searchLabel = new JLabel("搜索框");
        searchLabel.setBounds(50, 370, 100, 20);
        searchLabel.setFont(textfont1);
        searchLabel.setForeground(Color.white);
        root.add(searchLabel);

        //搜索文本框
        booknameTextField = new SearchTextField(student);
        booknameTextField.setBounds(50, 390, 140, 20);
        root.add(booknameTextField);
        authorTextField = new SearchTextField(student);
        authorTextField.setBounds(190, 390, 140, 20);
        root.add(authorTextField);
        ISBNTextField = new SearchTextField(student);
        ISBNTextField.setBounds(330, 390, 140, 20);
        root.add(ISBNTextField);
        publishTextField = new SearchTextField(student);
        publishTextField.setBounds(470, 390, 140, 20);
        root.add(publishTextField);
        dayTextField = new SearchTextField(student);
        dayTextField.setBounds(610, 390, 140, 20);
        root.add(dayTextField);

        //初始化搜索
        Search(student);

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,800,600);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void Search(Student student){
        ResultSet rs;
        Book book = new Book(booknameTextField.getText(),authorTextField.getText(),
                ISBNTextField.getText(),publishTextField.getText(),0);
        String day = dayTextField.getText();
        rs = new SQL().SB(student,book,day);
        ResultSet rs1;
        try{
            List sortkey = MyborrowTable.getRowSorter().getSortKeys();
            MyborrowTable.getRowSorter().setSortKeys(null);
            MyborrowTableModel.getDataVector().clear();
            MyborrowTableModel.fireTableDataChanged();
            Object[] rowdata;
            while(rs.next()){
                rs1 = new SQL().showBook(rs.getString("ISBN"));
                rowdata = new Object[5];
                rowdata[0] = rs1.getString("name");
                rowdata[1] = rs1.getString("author");
                rowdata[2] = rs1.getString("ISBN");
                rowdata[3] = rs1.getString("publish");
                rowdata[4] = rs.getString("day");
                MyborrowTableModel.addRow(rowdata);
            }
            MyborrowTable.getRowSorter().setSortKeys(sortkey);
            MyborrowTable.updateUI();
        }catch(Exception e1){}
    }
}

