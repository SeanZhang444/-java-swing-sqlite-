package frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static font.font.*;
import db.*;
import object.*;

class MReturnDialog extends JDialog{
    JButton confirmButton;
    public MReturnDialog(MReturnBook frame) {
        super(frame, "警告", true);
        setLayout(null);
        //文本框
        JLabel jl;
        jl = new JLabel("归还失败！");
        jl.setBounds(100, 40, 200, 20);
        jl.setFont(textfont1);
        add(jl);

        //确认按钮
        confirmButton = new JButton("确认");
        confirmButton.setBounds(100, 100, 80, 40);
        confirmButton.setFont(textfont1);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(confirmButton);

        setSize(300,200);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

class returnDialog2 extends JDialog{
    JButton confirmButton;
    public returnDialog2(MReturnBook frame, Student student, Book book, String day) {
        super(frame, "归还书籍", true);
        setLayout(null);
        //文本框
        JLabel jl;
        jl = new JLabel("确认归还该书籍？");
        jl.setBounds(80, 40, 200, 20);
        jl.setFont(textfont1);
        add(jl);

        //确认按钮
        confirmButton = new JButton("确认");
        confirmButton.setBounds(100, 100, 80, 40);
        confirmButton.setFont(textfont1);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(new SQL().deleteSB(student.getId(),book.getISBN(),day)!=0 && new SQL().returnBook(book)!=0){
                    frame.dispose();
                    dispose();
                }
                else{
                    dispose();
                    new MReturnDialog(frame);
                }
            }
        });
        add(confirmButton);

        setSize(300,200);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

public class MReturnBook extends JFrame {
    private JPanel root;
    private JLabel background,idLabel,nameLabel,booknameLabel,authorLabel,ISBNLabel,publishLabel, dayLabel;
    private JTextField idTextField,nameTextField,booknameTextField,authorTextField,ISBNTextField,publishTextField, dayTextField;
    private JButton enterButton,deleteButton;
    public MReturnBook(Student student,Book book,String day){
        setTitle("归还书籍");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);

        //学号标签
        idLabel = new JLabel("学号");
        idLabel.setBounds(70, 65, 100, 20);
        idLabel.setFont(textfont1);
        idLabel.setForeground(Color.white);
        root.add(idLabel);

        //学号文本框
        idTextField = new JTextField(12);
        idTextField.setBounds(120, 60, 150, 30);
        idTextField.setFont(textfont1);
        idTextField.setText(student.getId());
        idTextField.setEditable(false);
        root.add(idTextField);

        //姓名标签
        nameLabel = new JLabel("姓名");
        nameLabel.setBounds(300, 65, 100, 20);
        nameLabel.setFont(textfont1);
        nameLabel.setForeground(Color.white);
        root.add(nameLabel);

        //姓名文本框
        nameTextField = new JTextField(12);
        nameTextField.setBounds(350, 60, 150, 30);
        nameTextField.setFont(textfont1);
        nameTextField.setText(student.getName());
        nameTextField.setEditable(false);
        root.add(nameTextField);

        //书名标签
        booknameLabel = new JLabel("书名");
        booknameLabel.setBounds(70, 125, 100, 20);
        booknameLabel.setFont(textfont1);
        booknameLabel.setForeground(Color.white);
        root.add(booknameLabel);

        //书名文本框
        booknameTextField = new JTextField(12);
        booknameTextField.setBounds(120, 120, 150, 30);
        booknameTextField.setFont(textfont1);
        booknameTextField.setText(book.getName());
        booknameTextField.setEditable(false);
        root.add(booknameTextField);

        //作者标签
        authorLabel = new JLabel("作者");
        authorLabel.setBounds(300, 125, 100, 20);
        authorLabel.setFont(textfont1);
        authorLabel.setForeground(Color.white);
        root.add(authorLabel);

        //作者文本框
        authorTextField = new JTextField(12);
        authorTextField.setBounds(350, 120, 150, 30);
        authorTextField.setFont(textfont1);
        authorTextField.setText(book.getAuthor());
        authorTextField.setEditable(false);
        root.add(authorTextField);

        //ISBN标签
        ISBNLabel = new JLabel("ISBN");
        ISBNLabel.setBounds(70, 185, 100, 20);
        ISBNLabel.setFont(textfont1);
        ISBNLabel.setForeground(Color.white);
        root.add(ISBNLabel);

        //ISBN文本框
        ISBNTextField = new JTextField(12);
        ISBNTextField.setBounds(120, 180, 150, 30);
        ISBNTextField.setFont(textfont1);
        ISBNTextField.setText(book.getISBN());
        ISBNTextField.setEditable(false);
        root.add(ISBNTextField);

        //出版社标签
        publishLabel = new JLabel("出版社");
        publishLabel.setBounds(290, 185, 100, 20);
        publishLabel.setFont(textfont1);
        publishLabel.setForeground(Color.white);
        root.add(publishLabel);

        //出版社文本框
        publishTextField = new JTextField(12);
        publishTextField.setBounds(350, 180, 150, 30);
        publishTextField.setFont(textfont1);
        publishTextField.setText(book.getPublish());
        publishTextField.setEditable(false);
        root.add(publishTextField);

        //借阅日期标签
        dayLabel = new JLabel("借阅日期");
        dayLabel.setBounds(40, 255, 100, 20);
        dayLabel.setFont(textfont1);
        dayLabel.setForeground(Color.white);
        root.add(dayLabel);

        //借阅日期文本框
        dayTextField = new JTextField(12);
        dayTextField.setBounds(120, 250, 150, 30);
        dayTextField.setFont(textfont1);
        dayTextField.setText(day);
        dayTextField.setEditable(false);
        root.add(dayTextField);

        //归还按钮
        enterButton = new JButton("归还");          //定义按钮对象
        enterButton.setBounds(365, 245, 80, 40);
        enterButton.setFont(textfont1);
        enterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new returnDialog2(MReturnBook.this,student,book,day);
            }
        });
        root.add(enterButton);

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,600,400);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

}
