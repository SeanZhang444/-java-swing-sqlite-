package frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static font.font.*;
import db.*;
import object.*;

class AddDialog extends JDialog{
    private JButton confirmButton;
    public AddDialog(MAddBook frame) {
        super(frame, "警告", true);
        setLayout(null);
        //文本框
        JLabel jl;
        jl = new JLabel("添加失败：ISBN重复！");
        jl.setBounds(70, 40, 200, 20);
        jl.setFont(textfont1);
        add(jl);

        //确认按钮
        confirmButton = new JButton("确认");
        confirmButton.setBounds(100, 100, 80, 40);
        confirmButton.setFont(textfont1);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(confirmButton);

        setSize(300,200);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

public class MAddBook extends JFrame {
    private JPanel root;
    private JLabel background,nameLabel,authorLabel,ISBNLabel,publishLabel,numberLabel;
    private JTextField nameTextField,authorTextField,ISBNTextField,publishTextField,numberTextField;
    private JButton enterButton;
    public MAddBook(){
        setTitle("添加书籍");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);

        //书名标签
        nameLabel = new JLabel("书名");
        nameLabel.setBounds(70, 75, 100, 20);
        nameLabel.setFont(textfont1);
        nameLabel.setForeground(Color.white);
        root.add(nameLabel);

        //书名文本框
        nameTextField = new JTextField(12);
        nameTextField.setBounds(120, 70, 150, 30);
        nameTextField.setFont(textfont1);
        root.add(nameTextField);

        //作者标签
        authorLabel = new JLabel("作者");
        authorLabel.setBounds(300, 75, 100, 20);
        authorLabel.setFont(textfont1);
        authorLabel.setForeground(Color.white);
        root.add(authorLabel);

        //作者文本框
        authorTextField = new JTextField(12);
        authorTextField.setBounds(350, 70, 150, 30);
        authorTextField.setFont(textfont1);
        root.add(authorTextField);

        //ISBN标签
        ISBNLabel = new JLabel("ISBN");
        ISBNLabel.setBounds(70, 155, 100, 20);
        ISBNLabel.setFont(textfont1);
        ISBNLabel.setForeground(Color.white);
        root.add(ISBNLabel);

        //ISBN文本框
        ISBNTextField = new JTextField(12);
        ISBNTextField.setBounds(120, 150, 150, 30);
        ISBNTextField.setFont(textfont1);
        ISBNTextField.addKeyListener(new KeyAdapter(){
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(!((e.getKeyChar()>='0' && e.getKeyChar()<='9') || e.getKeyChar()=='-') || e.getKeyCode()==8 || ISBNTextField.getText().length()>=17){
                    e.consume();
                }
            }
        });
        root.add(ISBNTextField);

        //出版社标签
        publishLabel = new JLabel("出版社");
        publishLabel.setBounds(290, 155, 100, 20);
        publishLabel.setFont(textfont1);
        publishLabel.setForeground(Color.white);
        root.add(publishLabel);

        //出版社文本框
        publishTextField = new JTextField(12);
        publishTextField.setBounds(350, 150, 150, 30);
        publishTextField.setFont(textfont1);
        root.add(publishTextField);

        //数量标签
        numberLabel = new JLabel("数量");
        numberLabel.setBounds(70, 235, 100, 20);
        numberLabel.setFont(textfont1);
        numberLabel.setForeground(Color.white);
        root.add(numberLabel);

        //数量文本框
        numberTextField = new JTextField(12);
        numberTextField.setBounds(120, 230, 150, 30);
        numberTextField.setFont(textfont1);
        numberTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                if(e.getKeyChar()<'0' || e.getKeyChar()>'9' || e.getKeyCode()==8 || numberTextField.getText().length()>=5){
                    e.consume();
                }
            }
        });
        root.add(numberTextField);

        //确认按钮
        enterButton = new JButton("确认");
        enterButton.setBounds(365, 225, 80, 40);
        enterButton.setFont(textfont1);
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!nameTextField.getText().equals("") && !authorTextField.getText().equals("")
                        && !ISBNTextField.getText().equals("") && !publishTextField.getText().equals("")
                        && !numberTextField.getText().equals("")){
                    Book book = new Book(nameTextField.getText(),authorTextField.getText(),
                            ISBNTextField.getText(),publishTextField.getText(),Integer.parseInt(numberTextField.getText()));
                    if(new SQL().insertBook(book) != 0){
                        dispose();
                    }
                    else{
                        new AddDialog(MAddBook.this);
                    }
                }
            }
        });
        root.add(enterButton);

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,600,400);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

}
