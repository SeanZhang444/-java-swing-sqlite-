package frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static font.font.*;
import db.*;
import object.Manager;

class MInformationDialog extends JDialog{
    JButton confirmButton;
    public MInformationDialog() {
        super(new Frame(), "警告", true);
        setLayout(null);
        //文本框
        JLabel jl;
        jl = new JLabel("修改失败！");
        jl.setBounds(100, 40, 200, 20);
        jl.setFont(textfont1);
        add(jl);

        //确认按钮
        confirmButton = new JButton("确认");
        confirmButton.setBounds(100, 100, 80, 40);
        confirmButton.setFont(textfont1);
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(confirmButton);

        setSize(300,200);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

public class MInformation extends JFrame {
    private JPanel root;
    private JLabel background,idLabel,nameLabel;
    private JTextField idTextField,nameTextField;
    private JButton enterButton,passwordButton;
    public MInformation(Manager manager){
        setTitle("管理员信息");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);

        //id标签
        idLabel = new JLabel("ID");
        idLabel.setBounds(80,105,100,20);
        idLabel.setFont(textfont1);
        idLabel.setForeground(Color.white);
        root.add(idLabel);

        //id文本框
        idTextField = new JTextField(12);
        idTextField.setBounds(120, 100, 150, 30);
        idTextField.setFont(textfont1);
        idTextField.setText(manager.getId());
        idTextField.setEditable(false);
        root.add(idTextField);

        //名字标签
        nameLabel = new JLabel("名字");
        nameLabel.setBounds(310,105,100,20);
        nameLabel.setFont(textfont1);
        nameLabel.setForeground(Color.white);
        root.add(nameLabel);

        //名字文本框
        nameTextField = new JTextField(12);
        nameTextField.setBounds(350, 100, 150, 30);
        nameTextField.setFont(textfont1);
        nameTextField.setText(manager.getName());
        root.add(nameTextField);

        //确认按钮
        enterButton = new JButton("确认");
        enterButton.setBounds(130, 200, 120, 40);
        enterButton.setFont(textfont1);
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!nameTextField.getText().equals("")){
                    if(new SQL().updateManagerName(idTextField.getText(),nameTextField.getText())!=0){
                        dispose();
                    }else{
                        new MInformationDialog();
                    }
                }
            }
        });
        root.add(enterButton);

        //修改密码按钮
        passwordButton = new JButton("修改密码");
        passwordButton.setBounds(350, 200, 120, 40);
        passwordButton.setFont(textfont1);
        passwordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PasswordFrame(manager);
            }
        });
        root.add(passwordButton);

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,600,400);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

class PasswordFrame extends JFrame {
    private JPanel root;
    private JLabel background,newLabel,checkLabel;
    private JPasswordField newPasswordField, confirmPasswordField;
    private JButton enterButton,cancelButton;
    public PasswordFrame(Manager manager){
        setTitle("修改密码");
        root = new JPanel();      //定义面板容器
        setContentPane(root);
        setLayout(null);

        //新密码标签
        newLabel = new JLabel("新密码");
        newLabel.setBounds(140,85,100,20);
        newLabel.setFont(textfont1);
        newLabel.setForeground(Color.white);
        root.add(newLabel);

        //新密码文本框
        newPasswordField = new JPasswordField(12);
        newPasswordField.setBounds(200, 80, 240, 30);
        newPasswordField.setFont(textfont1);
        newPasswordField.setEchoChar('●');
        root.add(newPasswordField);

        //确认密码标签
        checkLabel = new JLabel("确认密码");
        checkLabel.setBounds(130,165,100,20);
        checkLabel.setFont(textfont1);
        checkLabel.setForeground(Color.white);
        root.add(checkLabel);

        //确认密码文本框
        confirmPasswordField = new JPasswordField(12);
        confirmPasswordField.setBounds(200, 160, 240, 30);
        confirmPasswordField.setFont(textfont1);
        confirmPasswordField.setEchoChar('●');
        root.add(confirmPasswordField);

        //确认按钮
        enterButton = new JButton("确认");
        enterButton.setBounds(150, 240, 120, 40);
        enterButton.setFont(textfont1);
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!newPasswordField.getText().equals("")
                        && newPasswordField.getText().equals(confirmPasswordField.getText())){
                    if(new SQL().updateManagerPassword(manager.getId(),newPasswordField.getText())!=0){
                        dispose();
                    }else{
                        new MInformationDialog();
                    }
                }
            }
        });
        root.add(enterButton);

        //取消按钮
        cancelButton = new JButton("取消");
        cancelButton.setBounds(320, 240, 120, 40);
        cancelButton.setFont(textfont1);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        root.add(cancelButton);

        //设置背景图片
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background.jpg")));
        background.setBounds(0,0,600,400);
        root.add(background);

        //设置窗口风格
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
